clc
clear all
close all
% area(x,y,'Facecolor','blue'); 

axis([0 50 0 20]);
Walls=[0,0,6,15;6,0,8,15;14,0,8,8;14,8,8,7;22,0,3,15;25,0,2,15;27,0,3,15;30,0,8,8;30,8,8,7;38,0,8,15;46,0,6,15;0,15,2,5;2,16.5,4,3.5;6,16.5,4,3.5;10,16.5,4,3.5;
14,16.5,4,3.5;18,16.5,4,3.5;22,16.5,4,3.5;26,16.5,4,3.5;30,16.5,4,3.5;34,16.5,4,3.5;38,16.5,4,3.5;42,16.5,4,3.5];
powers=zeros(0,6);
location = zeros(0,2);
inp=[-59.2983372511712,-106.688529830819,-108.773312205162,-114.384442481071,-117.801753479364];
distance = zeros(0,1);

   %finger print with step 2
   for xgraph=0:2:50
        x1 = [ 6 xgraph];
       x2 = [ 17.5 xgraph];
       x3 = [ 25.5 xgraph];   %% here we create the x-axis coordinate between access point and refrence point
       x4 = [ 33.5 xgraph];
       x5 = [ 45 xgraph];
        for ygraph=0:2:20
            y1 = [15.5625 ygraph ];
            y2 = [4 ygraph ];
            y3 = [15.5625 ygraph ];
            y4 = [4 ygraph ];
            y5 = [15.5625 ygraph ];
            z1 = zeros(1,0);
            z2 = zeros(1,0);
            z3 =zeros(1,0);
            z4 = zeros(1,0);
            z5 = zeros(1,0);
            for i=1 :size(Walls,1)
                hold on
               %%Drawing the room  
               xlimit = [Walls(i,1) Walls(i,3)+ Walls(i,1)];
               ylimit = [Walls(i,2)  Walls(i,4)+Walls(i,2)];
               xbox = xlimit([1 1 2 2 1]);
               ybox = ylimit([1 2 2 1 1]);
               power_recieved= zeros(1,5);
               if(((xlimit(1,1)==22) & (ylimit<= 15)) | ((xlimit(1,1)==27) & (ylimit<= 15)) )
               mapshow(xbox,ybox,'DisplayType','polygon','FaceColor', 'green');
               elseif (xlimit(1)==25)
                       mapshow(xbox,ybox,'DisplayType','polygon','FaceColor', 'none');
               elseif (ylimit<= 15)
                       mapshow(xbox,ybox,'DisplayType','polygon','FaceColor', 'magenta');
               else
                   mapshow(xbox,ybox,'DisplayType','polygon','FaceColor', 'cyan');
               end
                   
            
                       
               %%****************************************************************
            [xi1,yi1] = polyxpoly(x1,y1,xbox,ybox);
            [xi2,yi2] = polyxpoly(x2,y2,xbox,ybox);
            [xi3,yi3] = polyxpoly(x3,y3,xbox,ybox);
            [xi4,yi4] = polyxpoly(x4,y4,xbox,ybox);
            [xi5,yi5] = polyxpoly(x5,y5,xbox,ybox);
             if(isempty(xi1) )
                continue 
             else
                  z1(end+1)=size(xi1,2);
                  
                 
             end
             if(isempty(xi2))
                continue
             else
                 
                 z2(end+1)=size(xi2,2);
                    
                
             end
             
             if(isempty(xi3) )
                continue
             else
                 
                 z3(end+1)=size(xi3,2);
                  
             end
             
             
             if(isempty(xi4) )
                continue
             else
                  
                 z4(end+1)=size(xi4,2);
                 
             end
             
             if(isempty(xi5) )
                continue
             else   
                 z5(end+1)=size(xi5,2);
                     
             end
             
             
             
             
            end

                po=39.6*10^(-6);
                pt=-10 ;
                poindb = 10*log10(po);
                lamda = 0.125 ;
                d0=0.5;
                X1 = [6,15.5625 ;xgraph,ygraph];
                X2 = [17.5,4;xgraph,ygraph];
                X3 = [25.5,15.5625 ;xgraph,ygraph];
                X4 = [33.5,4 ; xgraph,ygraph];
                X5 = [45,15.5625;xgraph,ygraph];
                %distance 
                d1= pdist(X1,'euclidean');
                d2= pdist(X2,'euclidean');
                d3= pdist(X3,'euclidean');
                d4= pdist(X4,'euclidean');
                d5= pdist(X5,'euclidean');
                %adding the power of each AP for ONe point to the power
                %array 
                powers(end+1,1)= pt -30*log10(4*pi*(d1/lamda))-3*size(z1,2)
                powers(end,2)= pt -30*log10(4*pi*(d2/lamda))-3*size(z2,2)
                powers(end,3)= pt -30*log10(4*pi*(d3/lamda))-3*size(z3,2)
                powers(end,4)= pt -30*log10(4*pi*(d4/lamda))-3*size(z4,2)
                powers(end,5)= pt -30*log10(4*pi*(d5/lamda))-3*size(z5,2)
                powers(end,6)= pt -30*log10(4*pi*(d1/lamda))-3*size(z1,2) +pt -30*log10(4*pi*(d2/lamda))-3*size(z2,2)...
                    +pt -30*log10(4*pi*(d3/lamda))-3*size(z3,2)+pt -30*log10(4*pi*(d4/lamda))-3*size(z4,2)...
                    +pt -30*log10(4*pi*(d5/lamda))-3*size(z5,2)
%                 powers(end+1,1)=(poindb -10*3*log10(d1/d0)-3*size(z1,2));
%                 powers(end,2)= poindb -10*3*log10(d2/d0)-3*size(z2,2);
%                 powers(end,3)= poindb -10*3*log10(d3/d0)-3*size(z3,2);
%                 powers(end,4)= poindb -10*3*log10(d4/d0)-3*size(z4,2);
%                 powers(end,5)= poindb -10*3*log10(d5/d0)-3*size(z5,2);
                location(end+1,1)= xgraph ;
                location(end,2)= ygraph ;


        
     end
 
   
  

   
   
   end

   
  for xgraph=0:2:50
         for ygraph=0:2:20
             mapshow(xgraph,ygraph,'Marker','+');
         end
  end

rectangle('Position',[6 15.5625 1 0.5],'FaceColor',[0 0 0]);
rectangle('Position',[17.5 4 1 0.5],'FaceColor',[0 0 0]);
rectangle('Position',[25.5 15.5625 1 0.5],'FaceColor',[0 0 0]);
rectangle('Position',[33.5 4 1 0.5],'FaceColor',[0 0 0]);
rectangle('Position',[45 15.5625 1 0.5],'FaceColor',[0 0 0]);



ap1 = zeros(0,0)
x=1
y=1
for i=1 :size(powers,1)
    ap1(x,y)= powers(i,1)
    if(mod(i,11)==0)
        x=1;
        y=y+1;
    else 
        x=x+1;
    
    end
end  


ap2 = zeros(0,0)
x=1
y=1
for i=1 :size(powers,1)
    ap2(x,y)=powers(i,2)
    if(mod(i,11)==0)
        x=1;
        y=y+1;
    else 
        x=x+1;
    
    end
end  

ap3 = zeros(0,0)
x=1
y=1
for i=1 :size(powers,1)
    ap3(x,y)=powers(i,3)
    if(mod(i,11)==0)
        x=1;
        y=y+1;
    else 
        x=x+1;
    
    end
end  

ap4 = zeros(0,0)
x=1
y=1
for i=1 :size(powers,1)
    ap4(x,y)=powers(i,4)
    if(mod(i,11)==0)
        x=1;
        y=y+1;
    else 
        x=x+1;
    
    end
end  

ap5 = zeros(0,0)
x=1
y=1
for i=1 :size(powers,1)
    ap5(x,y)=powers(i,5)
    if(mod(i,11)==0)
        x=1;
        y=y+1;
    else 
        x=x+1;
    
    end
end 


ap6 = zeros(0,0)
x=1
y=1
for i=1 :size(powers,1)
    ap6(x,y)=powers(i,6)
    if(mod(i,11)==0)
        x=1;
        y=y+1;
    else 
        x=x+1;
    
    end
end 


for i=1 : size(powers,1)
distance(end+1,1)=(inp(1)-powers(i,1))^2 + (inp(2)-powers(i,2))^2 + (inp(3)-powers(i,3))^2.....
+(inp(4)-powers(i,4))^2 +(inp(5)-powers(i,5))^2 ;
end

locat=location(find(distance==min(distance)),:)
mapshow(locat(1,1),locat(1,2),'DisplayType','point','Marker','o','LineWidth', 3);

hold off

figure()
[xcon,ycon]=meshgrid(0:2:50 ,0:2:20);
contourf(xcon,ycon,ap1,20);
%colormap('hot');
title('AP1 Every 0.5 Refrence Points')
figure()
contourf(xcon,ycon,ap2,20);
title('AP2 Every 0.5 Refrence Points')
figure()
contourf(xcon,ycon,ap3,20);
title('AP3 Every 0.5 Refrence Points')
figure()
contourf(xcon,ycon,ap4,20);
title('AP4 Every 0.5 Refrence Points')
figure()
contourf(xcon,ycon,ap5,20);
title('AP5 Every 0.5 Refrence Points')
figure()
contourf(xcon,ycon,ap6,20);
title('All APS Every 0.5 Refrence Points')

 
